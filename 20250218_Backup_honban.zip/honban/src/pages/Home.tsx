// import React from 'react';

const Home = () => {
  return (
    <main>
      <h1>ホームページ</h1>
      <div>
        {/* <a href="/about">about50</a> */}
        {/* <Link to="about">about</Link> */}
      </div>
    </main>
  );
};

export default Home;
