// import React from 'react';
const About = () => {
  return (
    <>
      <div>アバウト</div>
    </>
  );
};

export default About;
